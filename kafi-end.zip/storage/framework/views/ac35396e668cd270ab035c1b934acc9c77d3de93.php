<div class="col-lg-4 mt-3">
          <a href="blogs/type">
          <div class="box">
                <img src="./assets/img/NoPath.png" class="img-fluid" alt="">
                <h3>اسم الشركه</h3>
                <p>هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز</p>
              </div>
          </a>
           </div><?php /**PATH D:\aly\kafi-end\resources\views/components/company-card.blade.php ENDPATH**/ ?>