<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<section id="register" class="bg-light">
                <div class="container" id="login-form">
                   <div class="row">
					   <div class="col-lg-4"></div>
					   <div class="col-lg-4">
						<form>
                        
							<div class="form-group">
								<label for="exampleInputEmail1">البريد الاكتروني / الايميل / الهاتف</label>
								<input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="ialyzaafan@gmail.com">
							  </div>
							  
	
							
							<div class="form-group">
							  <label for="exampleInputPassword1">كلمه المرور</label>
							  <input type="password" class="form-control" id="exampleInputPassword1" placeholder="كلمه المرور">
							</div>
							<div class="" style="width: 20%;">
								<input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
								<label class="form-check-label mr-4" for="flexCheckDefault">
								  تذكرني
								</label>
							  </div>
							<p>
								<a href="./forget-pass.html">هل نسيت كلمه المرور ؟</a>
							</p>
							

							<button type="submit" class="btn btn-primary">الدخول</button>

							<P style="text-align: center;"><a href="./register.html">ليس لديك حساب؟</a></P>
						  </form> 
					   </div>
					   
				   </div>  
                </div>
                  
               
                
            </section>


            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.adv-slider','data' => []]); ?>
<?php $component->withName('adv-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\aly\kafi-end\resources\views/login.blade.php ENDPATH**/ ?>