<div class="adv">
	<img src="./assets/img/adv2.jpg" class="image-fluid w-100 mx-auto mb-5" alt="">

</div><?php /**PATH D:\aly\kafi-end\resources\views/components/adv.blade.php ENDPATH**/ ?>