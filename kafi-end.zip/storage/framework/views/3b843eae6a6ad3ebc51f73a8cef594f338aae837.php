
            <div class="image-cover hero-banner single-items" style="background:url('assets/img/NoPath.png') no-repeat;">
				<div class="container">
					<div class="row">
						
						

						<div class="col-lg-12 col-md-12">
						 
							<div class="hero__p">
								<h1>شركات بيع اجهزه كهربائيه</h1>
							    
								<p>
									اول موقع متميز في مصر من البائع للمشتري مباشر بدون
									عموالات وخدمات متكاملة مع افضل الشركات
									كافي جروب اقرب اليك في الاختيار			</p>
							</div>
						</div>
					</div>
					
				</div>
			</div><?php /**PATH D:\aly\kafi-end\resources\views/components/banner.blade.php ENDPATH**/ ?>