<div class="sticky">

<div class="card mb-3">
    <div class="card-body">
        <p> اشترك الان في الباقه المجانيه للتواصل مع ملاك الوحدات مباشره بدون عملات
        </p> <a href="./pricing.html" class="btn our-btn">اضغط هنا</a>

    </div>
</div>
</div><?php /**PATH D:\aly\kafi-end\resources\views/components/purchase-now.blade.php ENDPATH**/ ?>