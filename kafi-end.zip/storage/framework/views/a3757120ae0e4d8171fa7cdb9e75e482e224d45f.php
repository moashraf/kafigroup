<div class="col-lg-12">
                                <div class="card mt-3">
                                    <div class="row no-gutters">


                                        <div class="col-sm-5 col-card-imgs">
                                            <div class="click">
                                                <div><a href=""><img src="./assets/img/real-estate/test-1.jpeg"
                                                            class="img-fluid mx-auto" alt="" /></a></div>
                                                <div><a href=""><img src="./assets/img/real-estate/test-3.jpeg"
                                                            class="img-fluid mx-auto" alt="" /></a></div>
                                                <div><a href=""><img src="./assets/img/real-estate/test-2.jpeg"
                                                            class="img-fluid mx-auto" alt="" /></a></div>
                                                <!-- <div><a href="single-property-1.html"><img src="assets/img/NoPath.png" class="img-fluid mx-auto" alt="" /></a></div>
                                                        <div><a href="single-property-1.html"><img src="assets/img/NoPath.png" class="img-fluid mx-auto" alt="" /></a></div>
                                                        <div><a href="single-property-1.html"><img src="assets/img/NoPath.png" class="img-fluid mx-auto" alt="" /></a></div> -->
                                            </div>
                                        </div>
                                        <div class="col-sm-7 order-lg-first col-card-details">
                                            <div class="card-body">
                                                <div class="listing-detail-wrapper">
                                                    <div class="listing-short-detail-wrap">
                                                        <div class="listing-short-detail">
                                                            <h4 class="listing-name verified"><a href="" class="">Banyon
                                                                    Tree</a></h4>
                                                            <!-- <h4 class="listing-name verified"><a href="single-property-1.html" class="prt-link-detail">Banyon Tree Realty</a></h4> -->
                                                            <span class="reviews_text">(42 عدد المشاهدات)</span>

                                                        </div>
                                                        <div class="listing-short-detail-flex">
                                                            <h6 class="listing-card-info-price">ج.م 7,000</h6>
                                                        </div>

                                                    </div>

                                                    <div class="foot-location">
                                                        200 التحرير, القاهره, مصر
                                                        <img src="assets/img/pin.svg" width="18" alt="" />
                                                    </div>
                                                </div>

                                                <div class="">
                                                    <div class="list-fx-features">
                                                        <div class="listing-card-info-icon">
                                                            <div class="inc-fleat-icon"><img src="assets/img/bed.svg"
                                                                    width="13" alt="" /></div>3 غرف
                                                        </div>
                                                        <div class="listing-card-info-icon">
                                                            <div class="inc-fleat-icon"><img
                                                                    src="assets/img/bathtub.svg" width="13" alt="" />
                                                            </div>1 حمام
                                                        </div>
                                                        <div class="listing-card-info-icon">
                                                            <div class="inc-fleat-icon"><img src="assets/img/move.svg"
                                                                    width="13" alt="" /></div>800 مساحه
                                                        </div>
                                                    </div>
                                                </div>
                                                <div>
                                                    <a href="./inner-listing.html" class="btn btn-success ">عرض</a>
                                                    <a href="#" class="btn btn-light ml-2"> حفظ <svg
                                                            xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                            fill="currentColor" class="bi bi-heart" viewBox="0 0 16 16">
                                                            <path
                                                                d="M8 2.748l-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
                                                        </svg></a>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div><?php /**PATH D:\aly\kafi-end\resources\views/components/property-card.blade.php ENDPATH**/ ?>