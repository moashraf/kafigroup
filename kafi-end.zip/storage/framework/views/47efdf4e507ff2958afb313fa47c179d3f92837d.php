<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
   <head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<title>al-Kafigroup</title>

	<!-- Custom CSS -->
	<link href="assets/css/styles.css" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/plugins/owl.carousel.css">
	<link rel="stylesheet" href="assets/css/plugins/popup.css">
	<link rel="stylesheet" href="assets/css/plugins/owl.theme.css">

	<!-- Custom Color Option -->
	<link href="assets/css/colors.css" rel="stylesheet">
	<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.rtl.min.css" integrity="sha384-mUkCBeyHPdg0tqB6JDd+65Gpw5h/l8DKcCTV2D2UpaMMFd7Jo8A+mDAosaWgFBPl" crossorigin="anonymous"> -->
	<link rel="stylesheet" href="assets/bootstrap.min.css">

</head>

<body class="blue-skin">

	<div id="loader-wrapper">
		<div id="loader">
			<div class="lds-circle"><div></div></div>
		</div>
		<div class="loader-section section-left"></div>
		<div class="loader-section section-right"></div>
	  </div>
	<!-- ============================================================== -->
	<!-- Preloader - style you can find in spinners.css -->
	<!-- ============================================================== -->
	<!-- <div id="preloader"><div class="preloader"><span></span><span></span></div></div> -->

	<!-- ============================================================== -->
	<!-- Main wrapper - style you can find in pages.scss -->
	<!-- ============================================================== -->
	<div id="main-wrapper">

		<!-- ============================================================== -->
		<!-- Top header  -->
		<!-- ============================================================== -->
		<!-- Start Navigation -->
		<div class="header header-light head-shadow">
			<div class="container-fluid">
				<nav id="navigation" class="navigation navigation-landscape container">
					<div class="nav-header">
						<a class="nav-brand" href="./index.html">
							<img src="assets/img/logo.jpg" width="70" class="logo" alt="" />
						</a>
						<div class="nav-toggle"></div>
					</div>
					<div class="nav-menus-wrapper" style="transition-property: none;">
						<ul class="nav-menu">

							<li class="active"><a href="./index.html">الرئيسيه</a>

							</li>



							<li><a href="JavaScript:Void(0);"><span class="submenu-indicator"></span>عقارات للبيع</a>
								<ul class="nav-dropdown nav-submenu">
									<li><a href="./sale-property.html"> عقارات للبيع كاش </a></li>
									<li><a href="./sale-property.html"> عقارات للبيع تقسيط </a></li>
									<li><a href="./real-estate-finance.html"> عقارات تصلح تمويل عقاري </a></li>
								</ul>
							</li>
							<li><a href=""><span class="submenu-indicator"></span>عقارات للايجار</a>
								<ul class="nav-dropdown nav-submenu">
									<li><a href="./rent-property.html">عقارات للايجار قانون جديد</a></li>
									<li><a href="./rent-property.html">عقارات للايجار مفروش</a></li>
								
								</ul>
							</li>

							<li><a href=""><span class="submenu-indicator"></span>الخدمات</a>
								<ul class="nav-dropdown nav-submenu">
									<li><a href="./sections.html">شركات نقل الاثاث</a></li>
									<li><a href="">شركات تشطيب و اعمال الديكور</a></li>
									<li><a href="">شركات بيع الاثاث المكتبي والمنزلي</a></li>
									<li><a href="">شركات بيع الاجهزه الكهربائيه</a></li>
								</ul>
							</li>

						

					
						</ul>

						<ul class="nav-menu nav-menu-social align-to-right">

							<li>
								<a href="./add-listing.html" class="text-success"><img src="assets/img/submit.svg"
										width="20" alt="" class="mr-2" /> اضف اعلانك مجانا </a>
								<!-- <a href="submit-property.html" class="text-success"><img src="assets/img/submit.svg" width="20" alt="" class="mr-2" />Add Property</a> -->
							</li>

							<li><a href="./register.html" class="text-success">سجل الان مجانا</a></li>

							<li class="add-listing"><a href=""><span class=""></span>الدخول</a>
								<ul class="nav-dropdown nav-submenu">

									<li><a href="./profile.html">الملف الشخصي</a></li>
									<li><a href="./favourites.html">سجل المفضلات</a></li>
									<li><a href="./login.html">تسجيل الدخول</a></li>
								</ul>
							</li>
						</ul>
					</div>
				</nav>
			</div>
		</div>
		<!-- End Navigation -->
		<!-- ============================================================== -->
		<!-- Top header  -->
		<!-- ============================================================== -->



		<!-- ============================ Hero Banner  Start================================== -->
		<div class="hero-slide-1">
			<div class="image-cover hero-banner single-items"
				style="background:url('assets/img/NoPath.png') no-repeat;">
				<div class="container">

					<div class="row">
						<div class="col-lg-6 col-md-6">
							<form action="">

								<div class="hero-search-wrap">
									<div class="hero-search">
										<!-- <h1>البحث</h1> -->
									</div>
									<div class="hero-search-content side-form">
										<div class="row">
											<div class="col-lg-12 col-md-12 col-sm-12">
												<div class="form-group">
													<div class="input-with-icon">
														<input required type="text" class="form-control"
															placeholder="بحث عن الموقع">
														<img src="assets/img/pin.svg" width="18" alt="" />
													</div>
												</div>
											</div>
										</div>

										<div class="row">
											<div class="col-lg-4 col-md-6 col-sm-6">
												<div class="form-group">
													<label>اقل سعر</label>
													<select required id="minprice" class="form-control">
														<option value="">&nbsp;</option>
														<option value="1">LE500</option>
														<option value="2">LE1000</option>
														<option value="3">LE1500</option>
														<option value="4">2000</option>
														<option value="5">3000</option>
													</select>
												</div>
											</div>
											<div class="col-lg-4 col-md-6 col-sm-6">
												<div class="form-group">
													<label>اعلى سعر</label>
													<select required id="maxprice" class="form-control">
														<option value="">&nbsp;</option>
														<option value="1"> ج.م 1000</option>
														<option value="2"> ج.م 1500</option>
														<option value="3"> ج.م 2000</option>
														<option value="4"> ج.م 3000</option>
														<option value="5"> ج.م 5000</option>
													</select>
												</div>
											</div>
											<div class="col-lg-4 col-md-6 col-sm-6">
												<div class="form-group">
													<label>نوع العرض</label>
													<select required id="status" class="form-control">
														<option value="">اختر</option>
														<option value="1">عقارات للبيع</option>
														<option value="2">عقارات للايجار</option>
														<option value="3">عقارات تصلح تمويل عقاري</option>

													</select>
												</div>
											</div>
										</div>



									</div>
									<div class="hero-search-action mb-2">
										<button type="submit" class="btn search-btn">بحث</button>
									</div>
									<div class="hero-search-action searchDetails">
										<button type="submit" class="btn search-btn2">بحث مفصل</button>
									</div>
								</div>
							</form>

						</div>

						<div class="col-lg-6 col-md-12">
							<div class="hero__p">
								<h1>كافي يكفيك ..!</h1>
								<p>
									اول موقع متميز في مصر من البائع للمشتري مباشر بدون
									عموالات وخدمات متكاملة مع افضل الشركات

								</p>
							</div>
						</div>
					</div>

				</div>
			</div>
			<!--slide 2-->

			<!--slide 3-->


		</div>
		<!-- ============================ Hero Banner End ================================== -->

		<!-- ============================ Latest Property للبيع Start ================================== -->
		<section class="" dir="ltr">
			<div class="container">

				<div class="row justify-content-center">
					<div class="col-lg-7 col-md-10 text-center">
						<div class="sec-heading center mb-4">
							<h2>اعلانات مميزه</h2>
							<p>
								لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه
							</p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-lg-12 col-md-12">
						<div class="property-slide">
                        <?php $__env->startComponent('components.card'); ?>    
   
 
                        <?php if (isset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453)): ?>
<?php $component = $__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453; ?>
<?php unset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.card'); ?>    
   
 
                        <?php if (isset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453)): ?>
<?php $component = $__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453; ?>
<?php unset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.card'); ?>    
   
 
                        <?php if (isset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453)): ?>
<?php $component = $__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453; ?>
<?php unset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.card'); ?>    
   
 
                        <?php if (isset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453)): ?>
<?php $component = $__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453; ?>
<?php unset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.card'); ?>    
   
 
                        <?php if (isset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453)): ?>
<?php $component = $__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453; ?>
<?php unset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.card'); ?>    
   
 
                        <?php if (isset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453)): ?>
<?php $component = $__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453; ?>
<?php unset($__componentOriginal5f59c4a1ca74a252b2d681d997164c3d2337c453); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


						</div>
					</div>
				</div>

			</div>
		</section>
		<!-- ============================ Latest Property للبيع End ================================== -->


		<!-- ============================ All Property ================================== -->
		<section class="bg-light">
			<div class="container">

				<div class="row justify-content-center">
					<div class="col-lg-7 col-md-10 text-center">
						<div class="sec-heading center">
							<h2>عقارات للبيع</h2>
							<p>لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه وضع

							</p>
						</div>
					</div>
				</div>


				<div class="row list-layout">
					<!-- Single Property Start -->
					<div class="col-lg-6 col-md-12">


						<div class="property-listing property-1">

							<div class="listing-img-wrapper">
								<!-- <a href="single-property-2.html"> -->
								<a href="">
									<img src="assets/img/real-estate/test-1.jpeg" class="img-fluid mx-auto" alt="" />
								</a>
							</div>

							<div class="listing-content">

								<div class="listing-detail-wrapper-box">
									<div class="listing-detail-wrapper">
										<div class="listing-short-detail">
											<h4 class="listing-name"><a href="">اسم الوحده السكنيه</a></h4>
										
										</div>
										<div class="list-price">
											<h6 class="listing-card-info-price">ج.م 4,000</h6>
										</div>
									</div>
								</div>

								<div class="price-features-wrapper">
									<div class="list-fx-features">
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/bathtub.svg" width="13"
													alt="" /></div>1 حمام
										</div>
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/bed.svg" width="13"
													alt="" /></div>3 غرف
										</div>
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/move.svg" width="13"
													alt="" /></div>800 مساحه
										</div>
									</div>
								</div>

								<div class="listing-footer-wrapper">
									<div class="listing-locate">
										<span class="listing-location"><i class="ti-location-pin"></i> التحرير, القاهره,
											مصر</span>
									</div>
									<div class="listing-detail-btn">
										<a href="" class="more-btn">عرض</a>
										<!-- <a href="single-property-2.html" class="more-btn">View</a> -->
									</div>
								</div>

							</div>

						</div>
					</div>

					<!-- Single Property Start -->
					<div class="col-lg-6 col-md-12">


						<div class="property-listing property-1">

							<div class="listing-img-wrapper">
								<!-- <a href="single-property-2.html"> -->
								<a href="">
									<img src="assets/img/real-estate/test-1.jpeg" class="img-fluid mx-auto" alt="" />
								</a>
							</div>

							<div class="listing-content">

								<div class="listing-detail-wrapper-box">
									<div class="listing-detail-wrapper">
										<div class="listing-short-detail">
											<h4 class="listing-name"><a href="">اسم الوحده السكنيه</a></h4>
										
										</div>
										<div class="list-price">
											<h6 class="listing-card-info-price">ج.م 4,000</h6>
										</div>
									</div>
								</div>

								<div class="price-features-wrapper">
									<div class="list-fx-features">
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/bathtub.svg" width="13"
													alt="" /></div>1 حمام
										</div>
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/bed.svg" width="13"
													alt="" /></div>3 غرف
										</div>
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/move.svg" width="13"
													alt="" /></div>800 مساحه
										</div>
									</div>
								</div>

								<div class="listing-footer-wrapper">
									<div class="listing-locate">
										<span class="listing-location"><i class="ti-location-pin"></i> التحرير, القاهره,
											مصر</span>
									</div>
									<div class="listing-detail-btn">
										<a href="" class="more-btn">عرض</a>
										<!-- <a href="single-property-2.html" class="more-btn">View</a> -->
									</div>
								</div>

							</div>

						</div>
					</div>

					<!-- Single Property Start -->
					<div class="col-lg-6 col-md-12">


						<div class="property-listing property-1">

							<div class="listing-img-wrapper">
								<!-- <a href="single-property-2.html"> -->
								<a href="">
									<img src="assets/img/real-estate/test-11.jpeg" class="img-fluid mx-auto" alt="" />
								</a>
							</div>

							<div class="listing-content">

								<div class="listing-detail-wrapper-box">
									<div class="listing-detail-wrapper">
										<div class="listing-short-detail">
											<h4 class="listing-name"><a href="">اسم الوحده السكنيه</a></h4>
									
										</div>
										<div class="list-price">
											<h6 class="listing-card-info-price">ج.م 4,000</h6>
										</div>
									</div>
								</div>

								<div class="price-features-wrapper">
									<div class="list-fx-features">
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/bathtub.svg" width="13"
													alt="" /></div>1 حمام
										</div>
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/bed.svg" width="13"
													alt="" /></div>3 غرف
										</div>
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/move.svg" width="13"
													alt="" /></div>800 مساحه
										</div>
									</div>
								</div>

								<div class="listing-footer-wrapper">
									<div class="listing-locate">
										<span class="listing-location"><i class="ti-location-pin"></i> التحرير, القاهره,
											مصر</span>
									</div>
									<div class="listing-detail-btn">
										<a href="" class="more-btn">عرض</a>
										<!-- <a href="single-property-2.html" class="more-btn">View</a> -->
									</div>
								</div>

							</div>

						</div>
					</div>

					<!-- Single Property Start -->
					<div class="col-lg-6 col-md-12">


						<div class="property-listing property-1">

							<div class="listing-img-wrapper">
								<!-- <a href="single-property-2.html"> -->
								<a href="">
									<img src="assets/img/real-estate/test-3.jpeg" class="img-fluid mx-auto" alt="" />
								</a>
							</div>

							<div class="listing-content">

								<div class="listing-detail-wrapper-box">
									<div class="listing-detail-wrapper">
										<div class="listing-short-detail">
											<h4 class="listing-name"><a href="">اسم الوحده السكنيه</a></h4>
											
										</div>
										<div class="list-price">
											<h6 class="listing-card-info-price">ج.م 4,000</h6>
										</div>
									</div>
								</div>

								<div class="price-features-wrapper">
									<div class="list-fx-features">
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/bathtub.svg" width="13"
													alt="" /></div>1 حمام
										</div>
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/bed.svg" width="13"
													alt="" /></div>3 غرف
										</div>
										<div class="listing-card-info-icon">
											<div class="inc-fleat-icon"><img src="assets/img/move.svg" width="13"
													alt="" /></div>800 مساحه
										</div>
									</div>
								</div>

								<div class="listing-footer-wrapper">
									<div class="listing-locate">
										<span class="listing-location"><i class="ti-location-pin"></i> التحرير, القاهره,
											مصر</span>
									</div>
									<div class="listing-detail-btn">
										<a href="" class="more-btn">عرض</a>
										<!-- <a href="single-property-2.html" class="more-btn">View</a> -->
									</div>
								</div>

							</div>

						</div>
					</div>


				</div>

				<!-- Pagination -->
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 text-center">
						<a href="" class="btn btn-theme-light rounded">اعرض المزيد</a>
						<!-- <a href="listings-list-with-sidebar.html" class="btn btn-theme-light rounded">Browse More Properties</a> -->
					</div>
				</div>

			</div>
		</section>
		<!-- ============================ All Featured Property ================================== -->

		<!-- ============================ Latest Property للبيع Start ================================== -->
		<section class="" dir="ltr">
			<div class="container">

				<div class="row justify-content-center">
					<div class="col-lg-7 col-md-10 text-center">
						<div class="sec-heading center mb-4">
							<h2>عقارات للايجار</h2>
							<p>
								لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه
							</p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-lg-12 col-md-12">
						<div class="property-slide">

						</div>
					</div>
				</div>

			</div>
		</section>
		<!-- ============================ Latest Property للبيع End ================================== -->

		<!-- ============================ Price Table Start ================================== -->









		<!-- ============================ Step How To Use Start ================================== -->
		<section>

			<div class="container">

				<!-- row Start -->
				<div class="row align-items-center">

					<div class="col-lg-7 col-md-9">
						<iframe width="100%" height="400" src="https://www.youtube.com/embed/CyYe0_zOFjs"
							frameborder="0"
							allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
							allowfullscreen></iframe>
					</div>

					<div class="col-lg-5 col-md-3">
						<div class="story-wrap explore-content">

							<h2 class="text-right">الكافي جروب</h2>
							<p class="text-right">
								تضع الحلول السهله بين يديك في اختيار عقارك
								مع كافي جروب اختار عقارك
								بنفسك بدون وسطاء

							</p>

						</div>
					</div>

				</div>
				<!-- /row -->

			</div>

		</section>

		<!-- sections-->
		<section class="bg-light">
			<div class="container">

				<div class="row justify-content-center">
					<div class="col-lg-7 col-md-10 text-center">
						<div class="sec-heading center">
							<h2>الاقسام المتاحه</h2>
							<p>
								لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه
							</p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-lg-12 col-md-12">
						<div class="property-slide">
				






						</div>
					</div>


				</div>



			</div>
		</section>
		<!-- ============================ Latest Property للبيع Start ================================== -->
		<section class="" dir="ltr">
			<div class="container">

				<div class="row justify-content-center">
					<div class="col-lg-7 col-md-10 text-center">
						<div class="sec-heading center mb-4">
							<h2>الاكثر بحثا</h2>
							<p>
								لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليتصور طريقه
							</p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-lg-12 col-md-12">
						<div class="property-slide">
				



						</div>
					</div>
				</div>

			</div>
		</section>
		<!-- ============================ Latest Property للبيع End ================================== -->

		<section>

			<div class="container">

				<!-- row Start -->
				<div class="row align-items-center">

					<div class="col-lg-12 col-md-12">
						<div class="adv-slider">
					

						</div>


					</div>




				</div>
				<!-- /row -->

			</div>


		</section>

		<!-- ============================ Call To Action ================================== -->
		<section class="bg call-to-act-wrap">
			<div class="container">
				<div class="row">

					<div class="col-lg-5"><img width="70%" src="./assets/img/4740491.jpg" height="90%" alt="">
					</div>
					<div class="col-lg-7">

						<div class="call-to-act">
							<div class="call-to-act-head">
								<h3 style="font-weight: 700;">كيف تختار صور اعلانك بجاذبية اكثر وبيع اسرع</h3>
								<p class="mt-3"> كافي جروب توفر لك افضل المصورين المحترفين
									باعلى جودة لتصوير اعلانك باحترافيه مميزه للمساعده في وصول نسب مشاهده اكثر</p>
								<a href="#" class="btn btn-call-to-act mt-3">احجز الان</a>


							</div>

						</div>

					</div>

				</div>
			</div>
		</section>
		<!-- ============================ Call To Action End ================================== -->

		<!-- ============================ Footer Start ================================== -->
		<footer class="dark-footer skin-dark-footer">
			<div>
				<div class="container">
					<div class="row">

						<div class="col-lg-5">
							<div class="footer-widget">
								<div class="footer-newsletter">
									<h4>نشرتنا الاخباريه</h4>
									<p>Tamen quem nulla legam noster magna Tamen quem nulla quae legam multos aute sint
										culpa legam noster magna</p>

									<form action="" method="">
										<input required type="email" name="email"><input type="submit" value="اشترك">
									</form>

								</div>
							</div>
						</div>

						<div class="col-lg-3">
							<div class="footer-widget">
								<h4>التواصل الاجتماعي</h4>

								<ul class="footer-bottom-social">
									<li><a href="#">تواصل عبر الفيسبوك <i class="ti-facebook"></i></a></li>
									<li><a href="#">تواصل عبر تويتر<i class="ti-twitter"></i></a></li>
									<li><a href="#">تواصل عبر انسجرام<i class="ti-instagram"></i></a></li>
									<li><a href="#">تواصل عبر لينكد ان<i class="ti-linkedin"></i></a></li>
									<li><a href="#">تواصل عبر اليوتيوب<i class="ti-youtube"></i></a></li>
								</ul>
							</div>
						</div>



						<div class="col-lg-4 col-md-4">
							<div class="footer-widget text-center">
								<img src="assets/img/footer-logo.png" class="img-footer" alt="" />
								<ul class="footer-menu">
									<li><a class="active-footer" href="./index.html">الرئيسيه</a></li>
									<li><a href="./about-us.html">من نحن</a></li>
									<li><a href="./terms-conditions.html">الشروط والاحكام</a></li>
									<li><a href="./contact-us.html">تواصل معنا</a></li>

								</ul>

							</div>
						</div>

					</div>
				</div>
			</div>

			<div class="footer-bottom">
				<div class="container">
					<div class="">

						<div>
							<p class="mb-0">© 2021. Cord Digital <a href=""></a> All Rights Reserved</p>
						</div>



					</div>
				</div>
			</div>
		</footer>
		<!-- ============================ Footer End ================================== -->





		<a id="back2Top" class="top-scroll" title="Back to top" href="#"><i class="ti-arrow-up"></i></a>


	</div>

	<!-- ============================================================== -->
	<!-- End Wrapper -->
	<!-- ============================================================== -->

	<!-- ============================================================== -->
	<!-- All Jquery -->
	<!-- ============================================================== -->
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/jquery.popup.js"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/rangeslider.js"></script>
	<script src="assets/js/select2.min.js"></script>
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/slick.js"></script>
	<script src="assets/js/slider-bg.js"></script>
	<script src="assets/js/li	ghtbox.js"></script>
	<script src="assets/js/imagesloaded.js"></script>
	<script src="assets/js/owl.carousel.js"></script>

	<script src="assets/js/custom.js"></script>
	<!-- ============================================================== -->
	<!-- This page plugins -->
	<!-- ============================================================== -->
	<!-- /GetButton.io widget -->
</body>

</html>
<?php /**PATH D:\aly\kafi-end\resources\views/welcome.blade.php ENDPATH**/ ?>