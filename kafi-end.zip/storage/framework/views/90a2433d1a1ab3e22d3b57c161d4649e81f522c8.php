<div class="col-lg-3">
<img src="<?php echo e(asset('assets/img/2021-conferences-vertical.jpg')); ?>" alt="">

</div><?php /**PATH D:\aly\kafi-end\resources\views/components/vertical-adv.blade.php ENDPATH**/ ?>