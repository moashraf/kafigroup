<div class="col-lg-6">
                                <div class="card vip">
                                    <img class="card-img" src="./assets/img/real-estate/test.png" alt="Bologna">
                                    <div class="card-img-overlay text-white d-flex flex-column justify-content-end align-content-end"
                                    >
                                        <div class="views">
                                            <div class="views-1">
                                                <span>مميز</span>


                                            </div>
                                            <div class="views-2">
                                                <i class="fa fa-eye"></i>
                                                <span>22</span>

                                            </div>
                                        </div>
                                        <h4 class="card-title" >Bologna</h4>
                                        <h6 class="card-subtitle mb-2">
                                            <div class="foot-location">
                                                200 التحرير, القاهره, مصر
                                                <img src="assets/img/pin.svg" width="18" alt="" />
                                            </div>
                                        </h6>

                                        <div class="card-text">

                                            <span>900,000 EGP</span>

                                        </div>
                                        <div class="">
                                            <div class="list-fx-features">
                                                <div class="listing-card-info-icon text-white">
                                                    <div class="inc-fleat-icon"><img src="assets/img/bed.svg" width="13"
                                                            alt="" /></div>3 غرف
                                                </div>
                                                <div class="listing-card-info-icon text-white">
                                                    <div class="inc-fleat-icon"><img src="assets/img/bathtub.svg"
                                                            width="13" alt="" /></div>1 حمام
                                                </div>
                                                <div class="listing-card-info-icon text-white">
                                                    <div class="inc-fleat-icon"><img src="assets/img/move.svg"
                                                            width="13" alt="" /></div>800 مساحه
                                                </div>
                                            </div>
                                        </div>
                                        <div class="footer-flex d-flex link">
                                            <a href="#" class="btn btn-success disabled">عرض</a>
                                            <a href="#" class="btn btn-light ml-2"> حفظ <svg
                                                    xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                    fill="currentColor" class="bi bi-heart" viewBox="0 0 16 16">
                                                    <path
                                                        d="M8 2.748l-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
                                                </svg></a>
                                        </div>
                                    </div>
                                </div>
                            </div><?php /**PATH D:\aly\kafi-end\resources\views/components/vip-card.blade.php ENDPATH**/ ?>