<x-layout>
<x-banner/>
<section class="articels" dir="rtl">
   <div class="container">
	<h2>جميع الشركات</h2>
    <div class="row">
    <x-company-card/>
    <x-company-card/>
    <x-company-card/>
    <x-company-card/>

</div>

<x-pagination/>
</div>
</section>

</x-layout>