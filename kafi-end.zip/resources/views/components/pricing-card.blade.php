<!-- Single Package -->
<div class="col-lg-4 col-md-4">
						<div class="flip-card mt-3">
							<div class="flip-card-inner">
								<div class="flip-card-front">
									<div class="pricing-wrap standard-pr">

										<div class="pricing-header">
											<h4 class="pr-value"><sup> ج.م</sup>0</h4>
											<h4 class="pr-title">الباقة المجانيه</h4>
										</div>
										<div class="pricing-body">
											<ul>
												<li class="available">عدد النقاط :50 نقطه </li>
												<li class="available">تعامل مباشر مع المالك</li>
											</ul>
										</div>


									</div>
								</div>
								<div class="flip-card-back">
									<p>اشترك اول مره مجانا
									<ul>
										<li>وحدات للبيع كل 50000 جنيه من السعر مقابل نقطة واحدة</li>
										<li>وحدات للايجار كل 250 جنيه من السعر مقابل نقطة واحدة</li>
									</ul>
									</p>
									<div class="pricing-bottom">
										<a href="#" class="btn-pricing">اشترك الان</a>
										<!-- <a href="#" class="btn-pricing">اختر باقتك</a> -->
									</div>
								</div>
							</div>
						</div>
					</div>