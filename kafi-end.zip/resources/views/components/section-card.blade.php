<div class="single-items">
								<div class="location-property-wrap">
									<div class="location-property-thumb">
										<!-- <a href="listings-list-with-sidebar.html"><img src="https://via.placeholder.com/1200x800" class="img-fluid" alt=""></a> -->
										<a href=""><img src="assets/img/NoPath.png" class="img-fluid" alt=""></a>
									</div>
									<div class="location-property-content">
										<div class="lp-content-flex">
											<h4 class="lp-content-title">اسم العقار</h4>
											<span>العنوان</span>
										</div>
										<div class="lp-content-right">
											<!-- <a href="listings-list-with-sidebar.html" class="lp-property-view"><i class="ti-angle-right"></i></a> -->
											<a href="" class="lp-property-view"><i class="ti-angle-left"></i></a>
										</div>
									</div>
								</div>



							</div>
