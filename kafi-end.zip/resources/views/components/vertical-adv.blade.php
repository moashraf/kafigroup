<div class="col-lg-3">
<img src="{{asset('assets/img/2021-conferences-vertical.jpg')}}" alt="">

</div>