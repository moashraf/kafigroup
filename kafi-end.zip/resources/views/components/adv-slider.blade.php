<section>
			
				<div class="container">
				
					<!-- row Start -->
					<div class="row align-items-center">

						<div class="col-lg-12 col-md-12">
							<div class="adv-slider">
								<div class="single-items"><img src="assets/img/adv1.jpg"  style="max-height: 350px; width: 100%;" class="img-fluid" alt=""></div> 
								<div class="single-items"><img src="assets/img/adv2.jpg"  style="max-height: 350px; width: 100%;" class="img-fluid" alt=""></div> 

							</div>
							
						</div>
						

				
						
					</div>
					<!-- /row -->					
					
				</div>
			

			</section>