<section class="bg call-to-act-wrap">
			<div class="container">
				<div class="row">

					<div class="col-lg-5"><img width="70%" src="./assets/img/4740491.jpg" height="90%" alt="">
					</div>
					<div class="col-lg-7">

						<div class="call-to-act">
							<div class="call-to-act-head">
								<h3 style="font-weight: 700;">كيف تختار صور اعلانك بجاذبية اكثر وبيع اسرع</h3>
								<p class="mt-3"> كافي جروب توفر لك افضل المصورين المحترفين
									باعلى جودة لتصوير اعلانك باحترافيه مميزه للمساعده في وصول نسب مشاهده اكثر</p>
								<a href="#" class="btn btn-call-to-act mt-3">احجز الان</a>


							</div>

						</div>

					</div>

				</div>
			</div>
		</section>