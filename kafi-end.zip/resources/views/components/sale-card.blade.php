	<!-- Single Property Start -->
    <div class="col-lg-6 col-md-12">


<div class="property-listing property-1">

    <div class="listing-img-wrapper">
        <!-- <a href="single-property-2.html"> -->
        <a href="">
            <img src="assets/img/real-estate/test-1.jpeg" class="img-fluid mx-auto" alt="" />
        </a>
    </div>

    <div class="listing-content">

        <div class="listing-detail-wrapper-box">
            <div class="listing-detail-wrapper">
                <div class="listing-short-detail">
                    <h4 class="listing-name"><a href="">اسم الوحده السكنيه</a></h4>
                
                </div>
                <div class="list-price">
                    <h6 class="listing-card-info-price">ج.م 4,000</h6>
                </div>
            </div>
        </div>

        <div class="price-features-wrapper">
            <div class="list-fx-features">
                <div class="listing-card-info-icon">
                    <div class="inc-fleat-icon"><img src="assets/img/bathtub.svg" width="13"
                            alt="" /></div>1 حمام
                </div>
                <div class="listing-card-info-icon">
                    <div class="inc-fleat-icon"><img src="assets/img/bed.svg" width="13"
                            alt="" /></div>3 غرف
                </div>
                <div class="listing-card-info-icon">
                    <div class="inc-fleat-icon"><img src="assets/img/move.svg" width="13"
                            alt="" /></div>800 مساحه
                </div>
            </div>
        </div>

        <div class="listing-footer-wrapper">
            <div class="listing-locate">
                <span class="listing-location"><i class="ti-location-pin"></i> التحرير, القاهره,
                    مصر</span>
            </div>
            <div class="listing-detail-btn">
                <a href="" class="more-btn">عرض</a>
                <!-- <a href="single-property-2.html" class="more-btn">View</a> -->
            </div>
        </div>

    </div>

</div>
</div>
